package Infnite.LmsProject;

public enum LeaveStatus {
	 PENDING, APPROVED,DENIED
}
