package Infnite.LmsProject;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Calendar;

public class LeaveDetailsDAO {
	
	Connection connection;
	PreparedStatement pst;
	
	public LeaveDetails searchByLeaveId(int leaveId) throws ClassNotFoundException, SQLException {
		connection = ConnectionHelper.getConnection();
		String cmd = "select * from leave_history where LEAVE_ID=?";
		pst = connection.prepareStatement(cmd);
		pst.setInt(1, leaveId);
		ResultSet rs = pst.executeQuery();
		LeaveDetails leaveDetails = null;
		if (rs.next()) {
			leaveDetails = new LeaveDetails();
			leaveDetails.setLeaveId(rs.getInt("LEAVE_ID"));
			leaveDetails.setEmpId(rs.getInt("EMP_ID"));
			leaveDetails.setNoOfDays(rs.getInt("LEAVE_NO_OF_DAYS"));
			leaveDetails.setLeaveStartDate(rs.getDate("LEAVE_START_DATE"));
			leaveDetails.setLeaveEndDate(rs.getDate("LEAVE_END_DATE"));
			leaveDetails.setLeaveType(LeaveType.valueOf(rs.getString("LEAVE_TYPE")));
			leaveDetails.setLeaveStatus(LeaveStatus.valueOf(rs.getString("LEAVE_STATUS")));
			leaveDetails.setLeaveReason(rs.getString("LEAVE_REASON"));
			
		}
		return leaveDetails;
	}
	public String approveDeny(int leaveId, int mgrId, String managerComments, String status) throws ClassNotFoundException, SQLException {
		LeaveDetails ld = searchByLeaveId(leaveId);
		connection = ConnectionHelper.getConnection();
		Employee emp = new EmployeeDao().searchEmploy(ld.getEmpId());
		LeaveDetails leaveDetails = searchByLeaveId(leaveId);
		int empId=leaveDetails.getEmpId();
		int noOfDays = leaveDetails.getNoOfDays();
		if (mgrId==emp.getMgrId()) {
			if (status.toUpperCase().equals("YES")) {
				String cmd = "Update leave_history SET LEAVE_STATUS='APPROVED', "
						+ "LEAVE_MNGR_COMMENTS=? where LEAVE_ID=?";
				pst = connection.prepareStatement(cmd);
				pst.setString(1, managerComments);
				pst.setInt(2, leaveId);
				pst.executeUpdate();
				return "Your Leave Approved...";
			} else {
				String cmd = "Update leave_history SET LEAVE_STATUS='DENIED', "
						+ "LEAVE_MNGR_COMMENTS=? where LEAVE_ID=?";
				pst = connection.prepareStatement(cmd);
				pst.setString(1, managerComments);
				pst.setInt(2, leaveId);
				pst.executeUpdate();
				cmd = "UPDATE EMPLOYEE SET EMP_AVAIL_LEAVE_BAL=EMP_AVAIL_LEAVE_BAL+? "
						+ " WHERE EMP_ID=?";
				pst = connection.prepareStatement(cmd);
				pst.setInt(1, noOfDays);
				pst.setInt(2, empId);
				pst.executeUpdate();
				return "Your Leave not Approved...";
			}
		} else {
			return "You Are unauthorized Manager...";
		}
	}
	public String applyLeave(LeaveDetails leaveDetails) throws ClassNotFoundException, SQLException {
		int days = getWorkDays(leaveDetails.getLeaveStartDate(), leaveDetails.getLeaveEndDate());
		java.util.Date today = new java.util.Date();
		long ms1 = leaveDetails.getLeaveEndDate().getTime() - today.getTime();
		long m1 = ms1 / (1000 * 24 * 60 * 60);
		int edays1 = (int) m1;
		edays1++;

		long ms2 = leaveDetails.getLeaveEndDate().getTime() - today.getTime();
		long m2 = ms2 / (1000 * 24 * 60 * 60);
		int edays2 = (int) m2;
		edays2++;
		Employee employee = new EmployeeDao().searchEmploy(leaveDetails.getEmpId());
		int leaveBalance = employee.getLeaveAvail();

		if (days <= 0) {
			return "LeaveStartDate cannot be greater than LeaveEndDate...";
		} else if (leaveBalance - days < 0) {
			return "Insufficient Leave Balance...";
		} else if (days != leaveDetails.getNoOfDays()) {
			return "Entered Days and No.of Days are Wrong...";
		} else if (edays1 < 0) {
			return "Leave End Date Cannot be Yesterday's Date...";
		} else if (edays2 < 0) {
			return "Leave StartDate Cannot be Yesterday's Date...";
		} else {
			leaveDetails.setNoOfDays(getWorkDays(leaveDetails.getLeaveStartDate(), leaveDetails.getLeaveEndDate()));
			connection = ConnectionHelper.getConnection();

			String cmd = "Insert into LEAVE_HISTORY(Emp_ID,Leave_Start_Date, "
					+ "Leave_End_Date,Leave_Type,Leave_Status,Leave_Reason,LEAVE_NO_OF_DAYS) "
					+ "VALUES(?,?,?,?,?,?,?)";
			pst = connection.prepareStatement(cmd);

			pst.setInt(1, leaveDetails.getEmpId());
			pst.setDate(2, leaveDetails.getLeaveStartDate());
			pst.setDate(3, leaveDetails.getLeaveEndDate());
			pst.setString(4, LeaveType.EL.name());

			pst.setString(5, LeaveStatus.PENDING.toString());
			pst.setString(6, leaveDetails.getLeaveReason());
			pst.setInt(7, leaveDetails.getNoOfDays());
			pst.executeUpdate();

			cmd = "Update Employee set EMP_AVAIL_LEAVE_BAL=EMP_AVAIL_LEAVE_BAL-? WHERE " + " EMP_ID=?";
			pst = connection.prepareStatement(cmd);
			pst.setInt(1, leaveDetails.getNoOfDays());
			pst.setInt(2, leaveDetails.getEmpId());
			pst.executeUpdate();

			return "Leave Applied Successfully...And LeaveBalance Updated...";
		}
	}
public int getWorkDays(Date startDate, Date endDate) {
	Calendar startCal = Calendar.getInstance();
	startCal.setTime(startDate);

	Calendar endCal = Calendar.getInstance();
	endCal.setTime(endDate);

	int workDays = 0;

	// Return 0 if start and end are the same
	if (startCal.getTimeInMillis() == endCal.getTimeInMillis() || startCal.getTimeInMillis()> endCal.getTimeInMillis()) {
		return 0;
	}

	

	do {
		// excluding start date

		if (startCal.get(Calendar.DAY_OF_WEEK) != Calendar.SATURDAY
				&& startCal.get(Calendar.DAY_OF_WEEK) != Calendar.SUNDAY) {
			++workDays;

		}
		startCal.add(Calendar.DAY_OF_WEEK, 1);
	} while (startCal.getTimeInMillis() <= endCal.getTimeInMillis()); // excluding end date

	return workDays;
} 

}
